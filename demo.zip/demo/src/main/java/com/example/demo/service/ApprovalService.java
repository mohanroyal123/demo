package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Approval;
import com.example.demo.entity.Product;
import com.example.demo.repository.ApprovalRepository;
import com.example.demo.repository.ProductRepository;

@Service
public class ApprovalService {
    @Autowired
    private ApprovalRepository approvalRepository;
    @Autowired
    private ProductRepository productRepository;

    public List<Approval> getProductsInApprovalQueue() {
        return approvalRepository.findByApprovedFalseOrderByRequestDateAsc();
    }

	public void approveProduct(Long approvalId) {
		// TODO Auto-generated method stub
		 Optional<Approval> approvalOpt = approvalRepository.findById(approvalId);

	        if (approvalOpt.isPresent()) {
	            Approval approval = approvalOpt.get();
	            approval.setApproved(true);
	            approvalRepository.save(approval);

	            // Update the product state as well
	            Optional<Product> productOpt = productRepository.findById(approval.getProductId());

	            if (productOpt.isPresent()) {
	                Product product = productOpt.get();
	                product.setStatus(true); // Mark the product as approved
	                productRepository.save(product);
	            }
	        } else {
	            throw new IllegalArgumentException("Approval not found with ID: " + approvalId);
	        }
	    }
		

	public void rejectProduct(Long approvalId) {
		// TODO Auto-generated method stub
        Optional<Approval> approvalOpt = approvalRepository.findById(approvalId);

        if (approvalOpt.isPresent()) {
            approvalRepository.delete(approvalOpt.get());
        } else {
            throw new IllegalArgumentException("Approval not found with ID: " + approvalId);
        }
		
	}



    
}
