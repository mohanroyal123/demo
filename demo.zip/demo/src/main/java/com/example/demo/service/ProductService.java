package com.example.demo.service;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Approval;
import com.example.demo.entity.Product;
import com.example.demo.repository.ApprovalRepository;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ApprovalRepository approvalRepository;

    public List<Product> listActiveProducts() {
        return productRepository.findByStatusTrueOrderByPostedDateDesc();
    }

    public List<Product> searchProducts(
            String productName, BigDecimal minPrice, BigDecimal maxPrice,
            LocalDateTime minPostedDate, LocalDateTime maxPostedDate) {
        return productRepository.searchProducts(productName, minPrice, maxPrice, minPostedDate, maxPostedDate);
    }

    public void createProduct(Product product) {
        // Validate the product price
        BigDecimal maxPriceLimit = new BigDecimal("10000");
        BigDecimal approvalPriceLimit = new BigDecimal("5000");

        if (product.getPrice().compareTo(maxPriceLimit) > 0) {
            // Price exceeds the maximum allowed price, push to approval queue
            pushToApprovalQueue(product);
        } else {
            productRepository.save(product);
        }
    }

    public void updateProduct(Long productId, Product updatedProduct) {
        Optional<Product> existingProductOpt = productRepository.findById(productId);

        if (existingProductOpt.isPresent()) {
            Product existingProduct = existingProductOpt.get();
            BigDecimal updatedPrice = updatedProduct.getPrice();

            // Calculate 50% of the previous price
            BigDecimal fiftyPercentOfPreviousPrice = existingProduct.getPrice().multiply(new BigDecimal("0.5"));

            if (updatedPrice.compareTo(fiftyPercentOfPreviousPrice) > 0) {
                // Price increase exceeds 50%, push to approval queue
                pushToApprovalQueue(updatedProduct);
            } else {
                // Update the product
                existingProduct.setName(updatedProduct.getName());
                existingProduct.setPrice(updatedProduct.getPrice());
                existingProduct.setStatus(updatedProduct.isStatus());
                productRepository.save(existingProduct);
            }
        }
    }

    public void deleteProduct(Long productId) {
        Optional<Product> productOpt = productRepository.findById(productId);

        if (productOpt.isPresent()) {
            Product product = productOpt.get();
            pushToApprovalQueue(product);
        }
    }

    private void pushToApprovalQueue(Product product) {
        Approval approval = new Approval();
        approval.setProductId(product.getId());
        approval.setRequestDate(LocalDateTime.now());
        approval.setApproved(false);

        approvalRepository.save(approval);
    }
}
